// Importamos as funcions do programa "funcions.js"
import { cargarArray, verArray } from "./funcions.js";


// Chamamos as funcions
cargarArray(1, 2, 3);

verArray();